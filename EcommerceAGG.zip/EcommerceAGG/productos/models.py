from django.db import models

# Create your models here.
class Producto(models.Model):
    titulo = models.CharField(max_length=100)
    descripcion = models.TextField()
    imagen = models.FilePathField(path="/img")
    precio = models.FloatField()