from django.shortcuts import render
from productos.models import Producto

# Create your views here.
def productos_index(request):
    return render(request,'productos_index.html',{})

def productos_catalogo(request):
    productos = Producto.objects.all()
    context = {
        'productos' : productos
    }

    return render(request,'productos_catalogo.html',context)

def productos_detail(request,pk):
    producto = Producto.objects.get(pk=pk)
    context = {
        'producto' : producto
    }

    return render(request,'productos_detail.html',context)
